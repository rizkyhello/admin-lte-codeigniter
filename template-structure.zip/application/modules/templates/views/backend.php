<!DOCTYPE html>
<html>
<head>
    <!-- <title>Truvel Guide</title> -->

<!--START LOAD HEADER-->
<?php $this->load->view('backend/head'); ?>
<!--END LOAD HEADER-->

</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="">

<!--START LOAD JS FILE-->
<?php //$this->load->view('backend/top_menu'); ?>
<!--START LOAD JS FILE-->
  
<!--START LOAD JS FILE-->
<?php $this->load->view('backend/main_menu'); ?>
<!--START LOAD JS FILE-->

<!--=================================================================================== -->
<!--================================= START LOAD CONTENT ============================== -->
<!--=================================================================================== -->
<?= $contents ?>
<!--=================================================================================== -->
<!--================================== END LOAD CONTENT =============================== -->
<!--=================================================================================== -->
</div>
<!-- FOOTER -->
<?php $this->load->view('backend/footer'); ?>

<!--START LOAD JS FILE-->
<?php $this->load->view('backend/jsfile'); ?>
<!--START LOAD JS FILE-->

<!--START LOAD SCRIPT JS FILE-->
<?php $this->load->view('backend/scriptjs'); ?>
<!--START LOAD SCRIPT JS FILE-->

</body>
</html>
