<!DOCTYPE html>
<html>
<head>
    <!-- <title>Truvel Guide</title> -->

<!--START LOAD HEADER-->
<?php $this->load->view('frontend/head'); ?>
<!--END LOAD HEADER-->

</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="">

<!--START LOAD JS FILE-->
<?php //$this->load->view('frontend/top_menu'); ?>
<!--START LOAD JS FILE-->
  
<!--START LOAD JS FILE-->
<?php $this->load->view('frontend/main_menu'); ?>
<!--START LOAD JS FILE-->

<!--=================================================================================== -->
<!--================================= START LOAD CONTENT ============================== -->
<!--=================================================================================== -->
<?= $contents ?>
<!--=================================================================================== -->
<!--================================== END LOAD CONTENT =============================== -->
<!--=================================================================================== -->
</div>
<!-- FOOTER -->
<?php $this->load->view('frontend/footer'); ?>

<!--START LOAD JS FILE-->
<?php $this->load->view('frontend/jsfile'); ?>
<!--START LOAD JS FILE-->

</body>
</html>
