  
  <script>
    /*============================================================================================*/
    /* Side Navigation */
    /*============================================================================================*/

    function openNav() {
        document.getElementById("mySidenav").style.width = "300px";
        document.getElementById("myOverlay").style.display = "block";
        document.getElementById("navScroll").style.overflow = "hidden";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("myOverlay").style.display = "none";
        document.getElementById("navScroll").style.overflow = "scroll";
    }

    // * Scrool Navbar module * \\ Rizky modified Kamis, 15/02/2018
    $(function () {
      $(document).scroll(function () {
        var $nav = $(".custom-navbar");
        $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
      });
    });

    

    /*============================================================================================*/
    /* Header Parallax */
    /*============================================================================================*/

    function EasyPeasyParallax() {
        var scrollPos = $(document).scrollTop();
        var targetOpacity;
        var elementHeight = $('.banner-parallax').height()/1.3;
        targetOpacity = 1-(elementHeight - scrollPos) / elementHeight;
        if(scrollPos==0){
          $('.header-overlay').css({
           'background-color': 'rgba(0, 0, 0, 0)'
        });
        }else{
        $('.header-overlay').css({
           'background-color': 'rgba(0, 0, 0, '+ targetOpacity +')'
        });
        }
        console.log(scrollPos,targetOpacity);
    };

    $(function(){
        $(window).scroll(function() {
           EasyPeasyParallax();
        });
    });

    /*============================================================================================*/
    /* Back to Top */
    /*============================================================================================*/

    $(document).ready(function() {
        var away = false;

        $('#back-to-top').click(function() {
            $("html, body").animate({
                scrollTop: 0
            }, 500);
        });
    });

    /*============================================================================================*/
    /* Anim-hc */
    /*============================================================================================*/

    $(document).ready(function() {
      window.sr = ScrollReveal();
      sr.reveal('.anim-hc');
      sr.reveal('.anim-hc2', { delay: 250 });
      sr.reveal('.anim-hc3', { delay: 500 });
    });

    /*============================================================================================*/
    /* Scroll Animation */
    /*============================================================================================*/

    Tu.tScroll({'t-element': '.fadeUp'})
    Tu.tScroll({'t-element': '.fadeIn'})
    Tu.tScroll({'t-element': '.fadeLeft'})
    Tu.tScroll({'t-element': '.fadeRight'})
    Tu.tScroll({'t-element': '.slideRight'})
    Tu.tScroll({'t-element': '.slideLeft'})
    Tu.tScroll({'t-element': '.slideDown'})
    Tu.tScroll({'t-element': '.slideUp'})

    /* tScroll Custom */
    Tu.tScroll({
      't-element': '.dd2 .fadeUp',
      't-position': 150
    })

    Tu.tScroll({
      't-element': '.gadgetBanner .slideRight',
      't-duration': 0.8,
      't-position': 150
    })

    /*============================================================================================*/
    /* Open Tab */
    /*============================================================================================*/

    function openContent(evt, forHotelGuest, appName, textName, appStore, appStoreMobile) {
        // Declare all variables
        var i, tabcontent, tablinks;

        // Get all elements with class="tabcontent" and hide them
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }

        // Get all elements with class="tablinks" and remove the class "active"
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }

        // Show the current tab, and add an "active" class to the button that opened the tab
        document.getElementById(forHotelGuest).style.display = "block";
        document.getElementById(appName).style.display = "block";
        document.getElementById(textName).style.display = "block";
        document.getElementById(appStore).style.display = "block";
        document.getElementById(appStoreMobile).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();

    /*============================================================================================*/
    /* Validate Email Animation */
    /*============================================================================================*/

    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    /*============================================================================================*/
    /* Header scroll to id location */
    /*============================================================================================*/

    $(document).ready(function(){
        // Add smooth scrolling to all links
        $("#truvelNavbar a").on('click', function(event) {

          // Make sure this.hash has a value before overriding default behavior
          if (this.hash !== "") {
              // Prevent default anchor click behavior
              event.preventDefault();

              // Store hash
              var hash = this.hash;

              // Using jQuery's animate() method to add smooth page scroll
              // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
              if($(window).width() >= 992) {
                $('html, body').animate({
                  scrollTop: $(hash).offset().top /*- 110 (Uncomment if not using jumptarget class)*/ 
                }, 800, function(){
                  // Add hash (#) to URL when done scrolling (default click behavior)
                  // window.location.hash = hash; (for direct exact position)
                });
            }
            else {
              $('html, body').animate({
                scrollTop: $(hash).offset().top /*- 80 (Uncomment if not using jumptarget class)*/ 
              }, 800, function(){
                // Add hash (#) to URL when done scrolling (default click behavior)
                // window.location.hash = hash; (for direct exact position)
              });
            }
          } // End if
        });
    });

    /*============================================================================================*/
    /* Sidenav scroll to id location */
    /*============================================================================================*/

    $(document).ready(function(){
        // Add smooth scrolling to all links
        $("#mySidenav a").on('click', function(event) {

          // Make sure this.hash has a value before overriding default behavior
          if (this.hash !== "") {
              // Prevent default anchor click behavior
              event.preventDefault();

              // Store hash
              var hash = this.hash;

              // Using jQuery's animate() method to add smooth page scroll
              // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
              if($(window).width() >= 992) {
                $('html, body').animate({
                  scrollTop: $(hash).offset().top - 110
                }, 800, function(){
                  // Add hash (#) to URL when done scrolling (default click behavior)
                  // window.location.hash = hash; (for direct exact position)
                });
            }
            else {
              $('html, body').animate({
                scrollTop: $(hash).offset().top - 80
              }, 800, function(){
                // Add hash (#) to URL when done scrolling (default click behavior)
                // window.location.hash = hash; (for direct exact position)
              });
            }
          } // End if
        });
    });
    /*============================================================================================*/
    /* Banner Video Fullscreen */
    /*============================================================================================*/

    var $video  = $('video'),
        $window = $(window); 

    $(window).resize(function(){
        
        var height = $window.height();
        $video.css('height', height);
        
        var videoWidth = $video.width(),
            windowWidth = $window.width(),
        marginLeftAdjust =   (windowWidth - videoWidth) / 2;
        
        $video.css({
            'height': height, 
            'marginLeft' : marginLeftAdjust
        });
    }).resize();

    /*============================================================================================*/
    /* Carousel Swipe */
    /*============================================================================================*/
    $('.carousel').bcSwipe({ threshold: 50 });

    /*============================================================================================*/
    /* Google Map Location */
    /*============================================================================================*/

    function myMap() {
      var map = new google.maps.Map(document.getElementById('googleMap'), {
          zoom: 17,
          center: {lat: -6.217598, lng: 106.75961}
      })

        marker = new google.maps.Marker({
            map: map,
            animation: google.maps.Animation.DROP,
            title: 'Truvel HQ',
            position: {lat: -6.217598, lng: 106.75961}
        });
        marker.addListener('click', toggleBounce);
    }

    function toggleBounce() {
        if (marker.getAnimation() !== null) {
            marker.setAnimation(null);
        } else {
            marker.setAnimation(google.maps.Animation.BOUNCE);
        }
    }

    /*============================================================================================*/
    /* Banner Video Fullscreen */
    /*============================================================================================*/

    var $video  = $('video'),
        $window = $(window); 

    $(window).resize(function(){
        
        var height = $window.height();
        $video.css('height', height);
        
        var videoWidth = $video.width(),
            windowWidth = $window.width(),
        marginLeftAdjust =   (windowWidth - videoWidth) / 2;
        
        $video.css({
            'height': height, 
            'marginLeft' : marginLeftAdjust
        });
    }).resize();

  </script>

  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBd48tflb0BiQK779WKTtjPJPmkOCmfpKY&callback=myMap" type="text/javascript">
  </script>
