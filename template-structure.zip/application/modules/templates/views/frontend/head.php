<!DOCTYPE html>
<html id="navScroll">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
  <!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/frontend/theme/css/bootstrap.css') ?>">
  <!-- Custom CSS -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/frontend/theme/css/custom.css') ?>">
  <link rel='stylesheet' media='screen and (max-width: 991px) and (min-width: 768px)' href='<?php echo base_url('assets/frontend/theme/css/custom-tablet.css') ?>'/>
  <link rel='stylesheet' media='screen and (max-width: 767px)' href='<?php echo base_url('assets/frontend/theme/css/custom-mobile.css') ?>'/>
  <!-- // shourcut icon -->
  <link rel="shortcut icon" href="https://assets.truvel.com/img/assets/truvelmobile/logo-min.png" type="image/x-icon" />

  <!-- ScrollReveal -->
  <script type="text/javascript" src="<?php echo base_url('assets/frontend/theme/js/scrollreveal.js') ?>"></script>
  <!-- T-Scroll -->
  <link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/frontend/theme/css/t-scroll.min.css') ?>">
  <script type="text/javascript" src="<?php echo base_url('assets/frontend/theme/js/t-scroll.min.js') ?>"></script>
  <!-- Custom JS -->
  <script type="text/javascript" src="<?php echo base_url('assets/frontend/theme/js/custom.js') ?>"></script>
  <!-- JQuery Swipe Carousel -->
  <script type="text/javascript" src="<?php echo base_url('assets/frontend/theme/js/jquery.bcSwipe.js') ?>"></script>

  <!-- // plugin phone number code internasional -->
  <link rel="stylesheet" href="https://www.jqueryscript.net/demo/jQuery-International-Telephone-Input-With-Flags-Dial-Codes/build/css/intlTelInput.css">
  <script type="text/javascript" src="<?php echo base_url('assets/frontend/theme/js/intlTelInput.js') ?>"></script>

  <!-- sweet alert -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.9.0/sweetalert2.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.9.0/sweetalert2.css" />
  <!-- JS SweetAlert-->   
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.9.0/sweetalert2.min.js"></script>

</head>
<body>