  <footer>
    <div class="footer-bg">
      <div class="row dd1">
        <div class="col-md-6 col-md-offset-3 col-sm-9">
          <div class="footer-subscribe">
            <div id="subsmail">
              <div id="subsmail-input">
                <input type="email" class="input-subs ws-xlight form-control1" name="email" id="email" maxlength="35" placeholder="Enter your Email" autocomplete="off" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your Email'">
                <!-- <label id="submit" class="subs-animate-label ws-xlight">Enter your Email</label> -->
                <button type="submit" id="submit-subscriber" class="footer-button-subs">Subscribe <img src="https://assets.truvel.com/img/assets/truvelmobile/arrow-right.png"></button>
                <div id="validationemailformat" style="display: none;"> *Invalid Format </div>
                <div id="validationemailrequired" style="display: none;"> *Email address required </div>
              </div>
              <div id="subsmail-success"></div>
            </div>
          </div>
        </div>
        <div class="col-md-1 col-md-offset-0 col-sm-1 col-sm-offset-0 col-xs-3 col-xs-offset-3 column-nxsubs" align="center">
          <a href="https://assets.truvel.com/img/assets/truvelmobile/ebrochure.pdf" download>
            <img src="https://assets.truvel.com/img/assets/truvelmobile/ico-download.png">
            <div class="ws-xlight">e-brochure</div>
          </a>
        </div>
        <div class="col-md-1 col-sm-1 col-xs-3 column-nxsubs" align="center">
          <div id="back-to-top">
            <img src="https://assets.truvel.com/img/assets/truvelmobile/ico-backtotop.png">
            <div class="ws-xlight">back to top</div>
          </div>
        </div>
      </div>
      <div class="footer-container">
        <div class="row">
          <div class="socmed-footer-area col-md-10 col-md-offset-1">
            <p class="ws-xlight">Connect with us</p>
            <div class="row">
              <div class="connect-info ws-light col-md-4 col-md-offset-2 col-sm-4 col-sm-offset-2 col-xs-12">
                <a class="footer-connect-link" href="tel:+622158902975">
                  <img src="https://assets.truvel.com/img/assets/truvelmobile/Assets-5-02.png"> +62 21 5890 2975
                </a>
              </div>
              <div class="connect-info ws-light col-md-4 col-sm-4 col-xs-12">
                <a class="footer-connect-link" href="mailto:hello@truvel.com">
                  <img src="https://assets.truvel.com/img/assets/truvelmobile/Assets-5-03.png"> 
                  hello@truvel.com
                </a>
              </div>
            </div>
            <div class="row">
              <div class="col-md-2 col-md-offset-1 col-sm-2 col-sm-offset-1 col-xs-2 col-xs-offset-1">
                <a href="https://www.facebook.com/TruvelID/">
                  <div class="ico-socmed1"></div>
                </a>
              </div>
              <div class="col-md-2 col-sm-2 col-xs-2">
                <a href="https://www.twitter.com/tuvelcare/">
                  <div class="ico-socmed2"></div>
                </a>
              </div>
              <div class="col-md-2 col-sm-2 col-xs-2">
                <a href="https://www.instagram.com/truvel_id/">
                  <div class="ico-socmed3"></div>
                </a>
              </div>
              <div class="col-md-2 col-sm-2 col-xs-2">
                <a href="https://www.linkedin.com/company/13310913">
                  <div class="ico-socmed4"></div>
                </a>
              </div>
              <div class="col-md-2 col-sm-2 col-xs-2">
                <a href="<?php echo base_url('blog') ?>">
                  <div class="ico-socmed5"></div>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="hidden-xs">
          <div class="row seven-cols">
            <div class="col-md-1 col-sm-1">
              <a class="ws-xlight" href="https://www.truvel.co.id/">Truvel.co.id</a>
            </div>
            <div class="col-md-1 col-sm-1">
              <a class="ws-xlight" href="https://www.truvel.com/">Truvel.com</a>
            </div>
            <div class="col-md-1 col-sm-1">
              <a class="ws-xlight" href="<?php echo base_url('terms') ?>">Terms & Conditions</a>
            </div>
            <div class="col-md-1 col-sm-1" align="center">
              <a class="ws-xlight" href="<?php echo base_url('home') ?>">
                <img class="grow" src="https://assets.truvel.com/img/assets/truvelmobile/logo-min.png">
              </a>
            </div>
            <div class="col-md-1 col-sm-1">
              <a class="ws-xlight">&#169;Truvel 2017.</a>
            </div>
            <div class="col-md-1 col-sm-1">
              <a class="ws-xlight">All rights reserved</a>
            </div>
            <div class="col-md-1 col-sm-1">
              <a class="ws-xlight" href="<?php echo base_url('sitemap') ?>">Sitemap</a>
            </div>
          </div>
        </div>
        <div class="hidden-lg hidden-md hidden-sm">
          <div class="row xs-seven-cols">
            <div class="col-xs-5">
              <div class="row">
                <div class="col-xs-12">
                  <a class="ws-xlight" href="https://www.truvel.co.id/">Truvel.co.id</a>
                </div>
                <div class="col-xs-12">
                  <a class="ws-xlight" href="https://www.truvel.com/">Truvel.com</a>
                </div>
                <div class="col-xs-12">
                  <a class="ws-xlight" href="<?php echo base_url('terms') ?>">Terms & Conditions</a>
                </div>
              </div>
            </div>
            <div class="col-xs-2" align="center">
              <a class="ws-xlight" href="#">
                <!-- <img class="grow" src="https://assets.truvel.com/img/assets/truvelmobile/logo-min.png"> -->
              </a>
            </div>
            <div class="col-xs-5">
              <div class="row">
                <div class="col-xs-12" align="right">
                  <a class="ws-xlight">&#169;Truvel 2017.</a>
                </div>
                <div class="col-xs-12" align="right">
                  <a class="ws-xlight">All rights reserved</a>
                </div>
                <div class="col-xs-12" align="right">
                  <a class="ws-xlight" href="<?php echo base_url('sitemap') ?>">Sitemap</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
</body>
</html>

<script type="text/javascript">

    /*============================================================================================*/
    /* Phone contact us international code phone & Input Digits only */
    /*============================================================================================*/
    $("#phone").intlTelInput();

    $(document).ready(function () {
      //called when key is pressed in textbox
      $("#phone").keypress(function (e) {
        //if the letter is not digit then display error and don't type anything
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            //display error message
            $("#errmsg").html("Digits Only").show().fadeOut("slow");
                  return false;
        }
      });
    });

    /*============================================================================================*/
    /* Create to subcriber */
    /*============================================================================================*/
    $('#submit-subscriber').click(function() {
      var email = $('#email').val();
      
      // jika data kosong
      if (email == '') {
        $("#email").css('border', '1px solid red');
        $("#validationemailrequired").show().css('color', 'red');
        $("#validationemailformat").hide();
        return false;
      } 
      
      // validation email format
      var atpos = email.indexOf("@");
      var dotpos = email.lastIndexOf(".");
      if (atpos<1 || dotpos < atpos+2 || dotpos+2 >= email.length) {
          $("#email").css('border', '1px solid red');
          $("#validationemailformat").show().css('color', 'red');
          $("#validationemailrequired").hide();
          return false;
      }

      $.ajax({
        url : '<?php echo base_url('home/create_subscriber') ?>',
        type : 'POST',
        data : { email : email },
        success : function(data) {
          var content = "<div class='success-subscribe'><h1 class='ws-medium'>Success!</h1><p class='ws-light'>Thank you for subscribing to our newsletter. You will receive updates on the latest Truvel news.</p></div>"
          $('#subsmail-input').hide();
          $('#subsmail-success').html(content);
        }
      });
    });

    /*============================================================================================*/
    /* Create contact us */
    /*============================================================================================*/
     $('#submit-contact').click(function() {
      
      // loading submit
      $("#load-submit").hide();
      $("#loading-submit").show();
      
      var first_name = $('#first_name').val();
      var last_name  = $('#last_name').val();
      var email      = $('#email_contact').val();
      var phone      = $('#phone').val();
      var subject    = $('#subject').val();
      var message    = $('#message').val();

      // validation from required & patern email
      if (first_name == '' || last_name == '' || phone == '' || subject == '' || message == '' || email == '') {
          // loading submit    
          $("#load-submit").show();
          $("#loading-submit").hide();

          if (first_name == '') {
            $("#first_name").css('border', '1px solid red');
            $("#validationfirst_name").show().css('color', 'red');
          } else {
            $("#first_name").css('border', '1px solid #ccc');
            $("#validationfirst_name").hide();
          }

          if (last_name == '') {
            $("#last_name").css('border', '1px solid red');
            $("#validationlast_name").show().css('color', 'red');
          } else {
            $("#last_name").css('border', '1px solid #ccc');
            $("#validationlast_name").hide();
          }

          // count phone string, maka ternilai required
          var count = phone.length; 
          if (count == 4 || count == 5 || count == 6) {
            $("#phone").css('border', '1px solid red');
            $("#validationphone").show().css('color', 'red');
            $("#validationphone_validate").hide();
          } else {
            $("#phone").css('border', '1px solid #ccc');
            $("#validationphone").hide();
            $("#validationphone_validate").hide();
          }

          if (subject == '') {
            $("#subject").css('border', '1px solid red');
            $("#validationsubject").show().css('color', 'red');
          } else {
            $("#subject").css('border', '1px solid #ccc');
            $("#validationsubject").hide();
          }

          if (message == '') {
            $("#message").css('border', '1px solid red');
            $("#validationmessage").show().css('color', 'red');
          } else {
            $("#message").css('border', '1px solid #ccc');
            $("#validationmessage").hide();
          }

          if (email == '') {
            $("#email_contact").css('border', '1px solid red');
            $("#validationemailrequired").show().css('color', 'red');
            $("#validationemailformat").hide();
            return false;
          } else {
            $("#email_contact").css('border', '1px solid #ccc');
            $("#validationemailrequired").hide();
            $("#validationemailformat").hide();
          }

          // validation email format \\
          var atpos = email.indexOf("@");
          var dotpos = email.lastIndexOf(".");
          if (atpos<1 || dotpos < atpos+2 || dotpos+2 >= email.length) {
              $("#email_contact").css('border', '1px solid red');
              $("#validationemailformat").show().css('color', 'red');
              $("#validationemailformat").show();
              $("#validationemailrequired").hide();
              // exit jika validasi ke cek   
              return false;          
          } else {
              $("#email").css('border', '1px solid #ccc');
              $("#validationemailformat").hide();
              $("#validationemailrequired").hide();
          }

          // exit jika validasi ke cek   
          return false;          
      }

      // validation email format \\
      var atpos = email.indexOf("@");
      var dotpos = email.lastIndexOf(".");
      if (atpos<1 || dotpos < atpos+2 || dotpos+2 >= email.length) {
          $("#email_contact").css('border', '1px solid red');
          $("#validationemailformat").show().css('color', 'red');
          $("#validationemailformat").show();
          $("#validationemailrequired").hide();

          // loading submit
          $("#load-submit").show();
          $("#loading-submit").hide();

          // exit jika validasi ke cek   
          return false;          
      } else {
          $("#email").css('border', '1px solid #ccc');
          $("#validationemailformat").hide();
          $("#validationemailrequired").hide();

          // loading submit
          $("#load-submit").hide();
          $("#loading-submit").show();
      }

      $.ajax({
        url : '<?php echo base_url('contact/create') ?>',
        type : 'POST',
        data : { first_name : first_name, last_name : last_name, email : email, phone : phone, subject : subject, message : message},
        success : function(data) {

          $('#first_name').val('');
          $('#last_name').val('');
          $('#email_contact').val('');
          // $('#phone').val('');
          $('#subject').val('');
          $('#message').val('');

          $("#first_name").css('border', '1px solid #ccc');
          $("#last_name").css('border', '1px solid #ccc');
          $("#email_contact").css('border', '1px solid #ccc');
          $("#phone").css('border', '1px solid #ccc');
          $("#subject").css('border', '1px solid #ccc');
          $("#message").css('border', '1px solid #ccc');

          $("#validationfirst_name").hide();
          $("#validationlast_name").hide();
          $("#validationphone").hide();
          $("#validationemailformat").hide();
          $("#validationemailrequired").hide();
          $("#validationsubject").hide();
          $("#validationmessage").hide();
        
          // loading submit
          $("#submit-contact").show();
          $("#load-submit").show();
          $("#loading-submit").hide();
          // alert success submit contact us user
          swal({
            title: 'Thank you!',
            text: 'Your message has been sent!',
            timer: 3500,
            showConfirmButton: false,
            type: 'success'
          });  
        }
      });

    });

</script>