<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
		
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get($table_name, $primary_key, $pk = NULL, $single = FALSE)
	{
		if ($pk != NULL) {
			$this->db->where($primary_key, $pk);
			$method = 'row';
		}

		elseif ($single == TRUE) {
			$method = 'row';
		}else {
			$method = 'result';
			$this->db->order_by($primary_key, "desc");
        }
        
		return $this->db->get($table_name)->$method();
	}

	public function get_by($where = NULL, $limit = NULL, $offset = NULL, $single = FALSE, $select = NULL)
	{
		if ($select != NULL) {
			$this->db->select($select);
		}

		if ($where != NULL) {
			$this->db->where($where);
		}

		if (($limit) && ($offset)) {
			$this->db->limit($limit, $offset);
		}

		elseif (($limit)) {
			$this->db->limit($limit);
		}

		return $this->get(NULL, $single);
	}

    public function store($data, $table_name, $batch = FALSE)
	{
		if ($batch == TRUE) {
			$this->db->insert_batch($table_name, $data);
		}else {
			$this->db->set($data);
			$this->db->insert($table_name);
			$id = $this->db->insert_id();
			return $id;
		}
	}

	public function update($table_name, $data, $where = array())
	{
		$this->db->set($data);
		$this->db->where($where);
		$this->db->update($table_name);
	}

	public function count($where = NULL)
	{
		if ($where) {
			$this->db->where($where);
		}

		$this->db->from($this->table_name);
		return $this->db->count_all_results();
	}

	public function delete($id, $table_name, $primary_key)
	{
		$this->db->where($primary_key, $id);
		$this->db->delete($table_name);
	}	

	public function create_subscriber($email)
	{
		$datetime = date('Y-m-d H:i:s');
		$query = $this->db->query("INSERT INTO subscribe (email, created_time) VALUES ('$email', '$datetime') ");
		return $query;
	}
	
}
		