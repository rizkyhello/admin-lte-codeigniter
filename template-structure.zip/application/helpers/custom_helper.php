<?php
// UPLOAD IMAGE
function upload_image($img_path, $field_name, $alt = NULL)
{
    $_this =& get_instance();
    $_this->load->library('upload');
    $path = '../assets/images/';

    $image_path = realpath(APPPATH . $path.$img_path);
    $files 						= $_FILES[$field_name];
    $rand 						= rand(11, 10000);

    /*
    | deklarasi lokasi file (path)
    | deklarasi Predefined Variables
    | $rand -> nilai random yang digunakan sebagai nama file yang diupload
    */

    $config['upload_path']		= $image_path;
    $config['allowed_types']	= 'jpg|jpeg|png';
    $ext											= explode('.', $files['name']);

    /*
    | konfigurasi lokasi upload
    | konfigurasi tipe gambar (ekstensi) yang diizinkan
    | mendapatkan array nama dan ekstensi file
    */
    
    $_FILES[$field_name]['name'] = $alt.'-'.$rand.'.'.$ext[1];

    /*
    | perubahan nama file
    */

    $_this->upload->initialize($config);
    $_this->upload->do_upload($field_name);
    
    /*
    | upload file
    */

    $image = $_this->upload->data();

    /*
    | memasukan data file yang diupload kedalam "$image"
    */
    
    $data['image'] 			= $image;
    $data['image_path'] = $image_path;

    return $data;

    /*
    | menampung nilai yang akan dikembalikan (return) kedalam "$data"
    | data dari "$image" yang bisa dikembalikan dapat dilihat di https://www.codeigniter.com/userguide3/libraries/file_uploading.html#class-reference
    | "image_path" mengembalikan nilai berupa lokasi file yang baru diupload
    */
}

/*
* upload_images digunakan untuk mengupload lebih dari 1 file gambar,
* parameter yang dibutuhkan, yaitu : 
    1. $img_path        -> lokasi tujuan file yang diupload
    2. $field_name  -> nilai dari attribut "name" pada tag input bertipe file
    3. $alt                 -> merupakan alt untuk gambar yang juga digunakan untuk mengganti nama gambar yang diupload
    4. $thumb_pre       -> prefix yang digunakan untuk nama thumbnail
    5. $wt                  -> (width thumbnail) nilai lebar untuk thumbnail
    6. $ht                  -> (height thumbnail) nilai tinggi untuk thumbnail
*/
function upload_images($img_path, $field_name, $name)
{
    $_this =& get_instance();
    $_this->load->library('upload','image_moo');
    $path = '../assets/images/';

    $image_path = realpath(APPPATH . $path.$img_path);

    $files              = $_FILES[$field_name];
    $num_rand           = rand(11, 10000);
    $count_files    = count($files);

    /*
    | "$count_files" menghitung jumlah $_FILES yang digunakan
    */

    $config['upload_path']      = $image_path;
    $config['allowed_types']    = 'jpg|jpeg|png';

    for ($i=0; $i < $count_files; $i++) {

        if (!empty($files['name'][$i])) {
            $unique_rand = $num_rand + $i; 
            $ext                                                            = explode('.', $files['name'][$i]);
            $_FILES[$field_name]['name']            = $name.'-'.$unique_rand.'.'.$ext[1];
            $_FILES[$field_name]['type']            = $files['type'][$i];
            $_FILES[$field_name]['tmp_name']    = $files['tmp_name'][$i];
            $_FILES[$field_name]['error']       = $files['error'][$i];
            $_FILES[$field_name]['size']            = $files['size'][$i];

            /*
            | perulangan dilakukan sebanyak filed input file yang digunakan
            | data akan diproses hanya jika nilai "$files" tidak kosong (empty)
            | data gambar diganti namanya dengan ketentuan "name-nilai_unik.ekstensi"
            */

            $_this->upload->initialize($config);
            $_this->upload->do_upload($field_name);

            $image = $_this->upload->data();

            // $_this->image_moo
            //     ->load($image_path.self::DS.$image['file_name'])
            //     ->resize($wt,$ht)
            //     ->save_pa($thumb_pre,'');

            /*
            | pembuatan thumbnail menggunakan library image-moo
            | untuk seluruh fungsi image-moo dapat dilihat di http://www.matmoo.com/digital-dribble/codeigniter/image_moo/
            | jika nilai $wt dan $ht == 0, maka thumbnail tidak akan diganti ukurannya
            */

            $new_name[] = $image['file_name'];
        }

        else {
            $new_name[] = '';
        }

        /*
        | seluruh data nama file (baik yang terisi ataupun tidak) akan ditampung dalam "$new_name" 
        */
    }

    return $new_name;
}


// DELETE IMAGE
function delete_image($img_path, $image_name, $thumb = NULL)
{
    $_this =& get_instance();
    $path = '../assets/images/';

    $image_path = realpath(APPPATH . $path.$img_path);

    if (!empty($image_name)) {
        unlink($image_path.'/'.$image_name);

        /*
        | gambar dihapus jika parameter pertama tidak kosong (empty)
        */
        
        if ($thumb){
            unlink($image_path.'/'.$thumb.$image_name);

            /*
            | thumbnail gambar akan dihapus jika parameter terakhir sesuai dengan perifix thumbnail
            */

        }
    }
}
/*Mapping array attraction*/
function mapping_tags($value) 
{
    return $value->tag_id;
}

function mapping_whats_on($value)
{
    return $value->whats_on_id;
}

/*menu class*/
function print_menu($menu, $class, $else = NULL)
{
    $_this =& get_instance();
    if ($menu == $_this->uri->segment(1)) {
        return $class;
    }
    else {
        return $else;
    }
}

function print_parent_menu($array = array(), $class)
{
    $_this =& get_instance();
    if (in_array($_this->uri->segment(1), $array)) {
        return $class;
    }
}

function lwd_send_email($to, $subject, $email)
{
    $_this =& get_instance();
    $_this->load->library('email');
    $_this->load->helper('email');

    $config['protocol'] = "smtp";
    $config['smtp_host'] = "ssl://smtp.gmail.com";
    $config['smtp_port'] = "465";
    $config['smtp_user'] = "syariflwd@gmail.com";
    $config['smtp_pass'] = "syarif12345";
    $config['charset'] = "utf-8";
    $config['mailtype'] = "html";
    $config['newline'] = "\r\n";

    $_this->email->initialize($config);

    $_this->email->from('syariflwd@gmail.com');
    $_this->email->to($to);
    $_this->email->subject($subject);
    $_this->email->message($email);
    $_this->email->send();
}