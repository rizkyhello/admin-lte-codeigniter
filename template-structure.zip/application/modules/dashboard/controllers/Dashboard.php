<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MX_Controller {

	public function __construct()
	{
		parent::__construct();

		// validasi login username empty
        // $Username = $this->session->userdata['username'];
        // if (empty($Username)) {
        //     redirect(base_url('lokaladmin'));
        // }
		// load model 
		// $this->load->model('user_model');
	 }
	
	public function index() {		
		$this->template->load('templates/backend', 'index');
	}
	
}
	